# Conversion Reference — Module 2

Use authoritative sources to verify conversion factors before coding.

## Core Course Conversions

- 12 inches = 1 foot
- 1 cubic foot ≈ 7.48052 US gallons

## Recommended References
- NIST Unit Conversion: https://www.nist.gov/pml/owm/metric-si/unit-conversion
- NIST SI Units: https://www.nist.gov/pml/owm/metric-si/si-units
- pytest documentation: https://docs.pytest.org/en/stable/
- Python documentation: https://docs.python.org/3/

## Important
Do not assume a conversion factor is correct because it appeared in AI-generated code. Verify the factor independently and cite the source in your README.
