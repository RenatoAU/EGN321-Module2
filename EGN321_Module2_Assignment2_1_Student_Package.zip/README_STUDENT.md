# EGN 321 — Module 2, Assignment 2.1
## Conversion Module — Student Starter Package

You are building a reusable Python unit-conversion module that will be used in later EGN 321 assignments.

### Final Goal
Create a trustworthy `units.py` module and a separate `test_units.py` file that prove the conversions work correctly.

### Required Deliverables
- `src/units.py`
- `tests/test_units.py`
- `README.md`
- `AI_LOG.md` if AI is used
- `requirements.txt`
- at least 8 meaningful tests
- at least 4 meaningful Git commits
- GitHub repository link

### Minimum Test Coverage
- 4 known-value conversion tests
- 2 reverse conversion tests
- 1 round-trip test
- 1 zero-value test

### Important Engineering Rule
**Convert once at the boundary, then keep the internal calculation in one unit system.**

Do not submit code you cannot explain or modify.
