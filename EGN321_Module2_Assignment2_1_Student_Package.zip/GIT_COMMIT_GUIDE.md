# Git Commit Guide — Assignment 2.1

Use at least four meaningful commits. A strong sequence could be:

1. `Add Module 2 conversion module structure`
2. `Implement length conversion functions`
3. `Add volume conversion functions and constants`
4. `Add known-value and reverse conversion tests`
5. `Add round-trip and zero-value tests`
6. `Document conversion sources and reuse`

Avoid vague commit messages such as:
- `update`
- `changes`
- `stuff`
- `final`
