# Assignment 2.1 Submission Checklist

## Module
- [ ] `src/units.py` exists.
- [ ] Function names clearly identify source and destination units.
- [ ] Each function performs one clear conversion.
- [ ] Important conversion factors are named constants where appropriate.
- [ ] No `input()` is used inside conversion functions.
- [ ] No printing is used inside conversion functions.
- [ ] Function docstrings identify input and output units.

## Tests
- [ ] `tests/test_units.py` exists.
- [ ] At least 4 known-value conversion tests.
- [ ] At least 2 reverse conversion tests.
- [ ] At least 1 round-trip test.
- [ ] At least 1 zero-value test.
- [ ] `pytest.approx()` is used where floating-point comparison is appropriate.
- [ ] All required tests pass.

## Documentation
- [ ] README describes supported conversions.
- [ ] Conversion factor sources are documented.
- [ ] Reuse expectations are explained.
- [ ] Known limitations are stated.
- [ ] AI use is documented if applicable.

## GitHub
- [ ] Repository is accessible to the instructor.
- [ ] At least 4 meaningful commits are present.
- [ ] I can explain every conversion and every test.
- [ ] Final submission is the repository link.
