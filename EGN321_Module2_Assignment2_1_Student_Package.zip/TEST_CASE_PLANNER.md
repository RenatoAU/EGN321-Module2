# Test Case Planner — Assignment 2.1

Plan the evidence before writing the test code.

| Test Name | Function | Input | Expected Output | Test Type | Why This Case Matters |
|---|---|---:|---:|---|---|
| | | | | Known value | |
| | | | | Known value | |
| | | | | Known value | |
| | | | | Known value | |
| | | | | Reverse | |
| | | | | Reverse | |
| | | | | Round trip | |
| | | | | Zero | |

## Independent Evidence
For each expected result, record where the value came from. Do not use the function being tested to generate its own expected answer.
